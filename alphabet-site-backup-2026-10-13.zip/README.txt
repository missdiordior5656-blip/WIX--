알파벳 최신주소 사이트 백업
백업 날짜: 2026-10-13 (Asia/Seoul)

1. 파일 구성
- index.html: Wix CMS에 연결된 현재 사이트 소스. HTML/CSS/JavaScript와 텔레그램 SVG 아이콘 포함.
- offline-preview.html: 백업 시점의 CMS 데이터를 내장한 독립 실행 미리보기. 더블클릭해서 열 수 있습니다.
- cms/backup.json: 컬렉션 구조, 권한, 항목 ID 및 콘텐츠.
- cms/content.json: 화면 표시용 데이터.
- cms/*.csv: 각 컬렉션의 가져오기용 CSV. 질문 7개, 페이지 설정 1개, 버튼 링크 4개.
- site-info.json: 기존 사이트 ID, 공개 OAuth 클라이언트 ID 및 사이트 주소.
- SHA256SUMS.txt: 파일 무결성 확인용 SHA256.

2. GitHub에 백업하기
ZIP을 압축 해제하고, 압축 해제된 폴더 안의 파일 전체를 GitHub 저장소에 업로드하세요.
ZIP 자체만 보관해도 되지만, 파일들을 올리면 변경 이력을 비교하기 쉽습니다.
이 작업에서는 GitHub 저장소를 생성하거나 업로드하지 않았습니다.

3. 평소 수정 위치
버튼 링크: https://manage.wix.com/dashboard/4a321f9e-02ea-4078-ab80-21daf29388aa/wix-cms/data/ButtonLinks
페이지 설정: https://manage.wix.com/dashboard/4a321f9e-02ea-4078-ab80-21daf29388aa/wix-cms/data/PageSettings
질문과 답변: https://manage.wix.com/dashboard/4a321f9e-02ea-4078-ab80-21daf29388aa/wix-cms/data/FaqItems
버튼 링크는 ButtonLinks 컬렉션의 url에서 수정합니다. PageSettings의 이전 URL 필드는 실제 링크보다 우선하지 않습니다.
ButtonLinks의 buttonKey는 변경하지 마세요.

4. 기존 Wix 사이트에 소스 복원하기
사이트 ID: 4a321f9e-02ea-4078-ab80-21daf29388aa
Wix Headless 배포 도구로 index.html을 기존 사이트에 업로드합니다.
배포할 파일은 index.html입니다. README, CMS 백업 및 offline-preview.html은 사이트에 공개할 필요가 없습니다.
CMS는 별도 저장소이므로 HTML 업로드만으로 CMS 데이터가 복원되지는 않습니다.

5. CMS 또는 새 사이트 복원하기
cms/backup.json에 있는 구조대로 PageSettings, FaqItems, ButtonLinks 컬렉션을 생성합니다.
컬렉션 ID와 필드 키/유형을 정확히 유지하고 읽기는 ANYONE, 쓰기는 관리자만 허용합니다.
각 CSV를 해당 컬렉션에 가져오고 BOOLEAN/NUMBER/URL 필드 형식과 줄바꿈을 확인합니다.
기존 데이터가 있는 컬렉션에 그대로 가져오면 중복될 수 있으므로 기존 항목과 비교 후 복원합니다.
새 Wix Headless 사이트로 옮길 경우 새 사이트의 공개 OAuth 클라이언트 ID를 index.html의 clientId에 설정해야 합니다.
기존 사이트를 계속 사용하면 현재 clientId를 유지합니다.
복원 후 FAQ 순서와 4개 버튼 URL을 확인합니다.

6. 백업 범위
이 백업은 소스와 현재 CMS 콘텐츠의 스냅샷입니다. 이후 CMS 수정은 이 ZIP이나 GitHub에 자동 반영되지 않습니다.
도메인, DNS, 결제 플랜, 계정 설정 및 Google Search Console 설정은 포함하지 않습니다.
인증 비밀키/로그인 토큰은 포함하지 않습니다. 소스의 clientId는 방문자용 공개 식별자입니다.
offline-preview.html은 Wix CMS와 연결하지 않으며 백업 당시 데이터를 보여줍니다.
index.html은 Wix CMS 및 인터넷 연결이 필요합니다.

